require 'spec_helper'

describe Zombie do
	its(:name) { should== 'Ash' }
	
end
